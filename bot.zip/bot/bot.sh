#!/bash/bin
    echo 	"\033[1;31m/````````````````````````````\"
   echo "\033[1;31m||Tools By : Firman717        ||"
   echo "||subscribe channel Firman YT ||"
    echo "\____________________________/"
    echo "untuk membuat bot whatsall?"
    echo "silahkan kalian masukan pilihan dibawah ini"
    echo "y (untuk Ya)"/n (untuk tidak)
    echo "----------------------------"
read -p "silahkan masukan piliham anda di sini :"pilih
if [ $pilih = "y" ]
sleep 1.0
    echo "memulai penginstallan bot whatsapp"
then
pkg update && pkg upgrade -y
pkg install git
pkg install nodejs
pkg install wget
pkg install unzip
git clone https://github.com/firman717/botf7
cd botf7
unzip rikabot.zip
cd rikabot
cd rikabot
pkg install tesseract
pkg install ffmpeg
npm i -g cwebp
npm i node-tesseract-ocr
npm i -g ytdl
npm i
npm i got
node index.js

elif
    echo "oke anda telah membatalkannya"
sleep 1.0
exit
else
    echo "maaf pilihan yang anda ketik"
    echo "tidak ada pada daftar pilihan!!"
    exit
fi